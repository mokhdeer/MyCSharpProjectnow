using Microsoft.AspNetCore.Mvc;
using System;

namespace WeatherApp.Controllers
{
    public class AgeCalculatorController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Index(DateTime birthDate)
        {
            if (birthDate == DateTime.MinValue)
            {
                ViewBag.Message = "Please enter a valid date.";
                return View();
            }

            if (birthDate > DateTime.Today)
            {
                ViewBag.Message = "Date of birth cannot be in the future.";
                return View();
            }

            var ageDetails = CalculateExactAge(birthDate);
            ViewBag.BirthDate = birthDate;
            ViewBag.Years = ageDetails.years;
            ViewBag.Months = ageDetails.months;
            ViewBag.Days = ageDetails.days;
            ViewBag.TotalDays = (DateTime.Today - birthDate).Days;

            return View();
        }

        private (int years, int months, int days) CalculateExactAge(DateTime birthDate)
        {
            DateTime today = DateTime.Today;

            int years = today.Year - birthDate.Year;
            int months = today.Month - birthDate.Month;
            int days = today.Day - birthDate.Day;

            if (days < 0)
            {
                months--;
                DateTime previousMonth = today.AddMonths(-1);
                days += DateTime.DaysInMonth(previousMonth.Year, previousMonth.Month);
            }

            if (months < 0)
            {
                years--;
                months += 12;
            }

            return (years, months, days);
        }
    }
}
